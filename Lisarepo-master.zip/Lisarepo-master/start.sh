git clone https://token:x-oauth-basic@github.com/Ichappi23/LISA.git bot;
cd bot;
python bot.py